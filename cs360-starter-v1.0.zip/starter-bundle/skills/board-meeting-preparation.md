---
skill_name: board-meeting-preparation
description: Board meeting decks, metrics dashboards, compelling narratives, and Q&A preparation
category: Business & Strategy
version: 1.0.0
---

# Board Meeting Preparation

## Pre-Meeting Planning (2-3 weeks before)

### Quarterly Context Setting
1. **What story are you telling?**
   - Last quarter: What were the goals? Did you hit them?
   - This quarter: One headline (beating targets, pivoting, launching new product)
   - Forward: 2-3 key bets for next quarter (and your confidence level)

2. **Identify key narratives** (pick 2-3, not 5+):
   - **Tailwind narrative**: Market expanding, new customer segment opening, product inflection
   - **Challenge narrative**: Competitive pressure, retention drop, hiring slowdown (transparency builds trust)
   - **Bet narrative**: New market entry, product pivot, pricing change (show the data behind it)

3. **Stakeholder prep** (1 week before):
   - Call each board member individually (15-20 min calls)
   - Share deck 3 days before meeting (not day-of)
   - Ask: "Any topics you want me to deep dive on?"
   - Flag surprises privately first (bad quarters, missed targets, leadership changes)

## Deck Structure (20-25 slides max)

### Slide 1: Cover Page
- Company name, logo, meeting date
- CEO/Founder name, quarter, year

### Slide 2-3: Letter from CEO (2 slides)
**Slide 2**: Headline narrative + 3 bullet points (50 words max each)
- What we accomplished this quarter
- Key metric that matters most (growth %, user count, $ milestone)
- One forward-looking insight

**Slide 3**: Forward outlook
- Next quarter's focus (1-2 themes max)
- Key risks to watch
- Board support needed (capital raise, hiring, partnerships?)

### Slides 4-6: Business Metrics (Scorecard)
Create a 2x3 table on each slide of your most important metrics:

**Slide 4: Growth & Scale**
| Metric | This Qtr | Last Qtr | Plan | YoY |
|--------|----------|----------|------|-----|
| ARR    | $2.5M    | $2.1M    | $2.3M | +85% |
| Logo Count | 185 | 175 | 190 | +45% |
| CAC | $8K | $9.5K | <$8K | -16% |

**Slide 5: Profitability & Efficiency**
| Metric | This Qtr | Status |
|--------|----------|--------|
| Gross Margin | 78% | ↑ vs plan |
| Magic Number | 0.92 | On track (need 1.0+) |
| Burn Rate | $320K/mo | $50K/mo improvement YoY |
| Runway | 18 months | 12mo funding target |

**Slide 6: Customer & Product**
| Metric | This Qtr | Last Qtr | Target |
|--------|----------|----------|--------|
| NPS | 52 | 48 | 60 |
| Churn % | 4.2% | 4.8% | <3% |
| Expansion Revenue % | 32% | 28% | 35% |

### Slides 7-9: Deep Dive #1 (Growth or New Product)
Use this format if one driver deserves exploration:

**Slide 7**: Headline + visual (graph or chart)
- Title: "New product segment contributing 35% of growth"
- Graph: Revenue contribution over last 3 quarters (stacked bar)

**Slide 8**: Customer story or proof
- Case study: "Customer X achieved $500K savings"
- Metric: "NPS in new segment: 65 (vs. 52 company average)"

**Slide 9**: What's next
- Roadmap: 2-3 next initiatives in this area
- Investment needed: Team size, budget, timeline

### Slides 10-11: Deep Dive #2 (Challenge or Pivot)
**Slide 10**: What's happening + why
- Headline: "Churn elevated in SMB segment"
- Root cause: "Product/market fit below threshold; moving upmarket"
- Data: Churn by segment table (SMB 8%, Mid-market 3%, Enterprise 1.5%)

**Slide 11**: Response plan
- What we're doing: Shifting go-to-market, product simplification, pricing change
- Timeline: 6-month pivot
- Success metrics: Churn <2% by Q3

### Slide 12-13: Competitive Landscape & Market
**Slide 12**: Category positioning
- Market growth: "TAM $50B, growing 25% CAGR"
- Your position: "Top 3 player by revenue, only native integration platform"
- Threat: "Consolidation: [Competitor] acquired [Other competitor]"

**Slide 13**: Competitive win rate & lost deals
- Win rate: vs. Competitor A (50%), vs. Competitor B (65%), vs. in-house (80%)
- Lost deal reasons (pie chart): Price 35%, feature gap 30%, process 20%, other 15%
- Response: "Investing in feature X to close 30% of feature gaps"

### Slide 14-15: Talent & Ops
**Slide 14**: Headcount & hiring
- Current: [Breakdown by function: Sales 8, Engineering 12, Ops 3, etc.]
- Plan: Add 6 this quarter (2 Sales, 3 Engineering, 1 Ops)
- Attrition: 0% this quarter (vs. industry 12% quarterly)

**Slide 15**: Retention & culture
- Glassdoor: 4.5/5.0 stars, 85% recommend to friend
- Engagement: eNPS 45 (target 50)
- Retention goal: Maintain <2% quarterly attrition

### Slides 16-17: Capital & Funding
**Slide 16**: Runway & ask
- Current cash: $1.2M
- Monthly burn: $320K
- Runway: 18 months
- Funding ask: $5M Series A (timeline: close by end of Q2)

**Slide 17**: Use of funds
- Engineering (50%, $2.5M): 4 engineers, expanded infrastructure
- Sales & Marketing (30%, $1.5M): 2 AEs, demand generation
- Operations (20%, $1M): Finance, HR, product manager

### Slides 18-19: Key Risks & Mitigants
**Slide 18**: Top 3 risks
1. **Competitive** — Two new entrants launched; mitigation: 6-month product roadmap advantage
2. **Hiring** — Engineering talent constrained; mitigation: Expanded recruiting, referral bonus
3. **Macro** — Slowdown in customer spending; mitigation: Land-and-expand motion, reduce CAC

**Slide 19**: Opportunities
- 2-3 optionality plays (new markets, product extensions, strategic partnerships)
- Board support needed: Introductions, strategic insight, network access

### Slide 20-21: Ask & Next Steps
**Slide 20**: What we need from the board
- Intros to [3-5 strategic customers, enterprise partners, customers in new segment]
- Strategic input on [pricing, market positioning, competitive threat]
- Approval: [Any governance decisions: hiring, budget, strategy pivot]

**Slide 21**: Next quarter preview
- 2-3 key initiatives
- Expected outcomes (metrics)
- Timeline

## Creating a Compelling Narrative (Not Just Data)

### The "Story Arc" Formula
**Opening** (1 sentence, emotional):
"Six months ago, we made a bet on the enterprise market. Today I'm excited to share the early results."

**Complication** (2-3 sentences, tension):
"Enterprise customers needed features we hadn't built. That meant slowing our SMB growth. It was a tough call."

**Turn** (1 sentence, insight):
"But what we learned was something unexpected: the enterprise segment had 10x the lifetime value."

**Resolution** (3 sentences, outcome):
"So we shifted. We rebuilt the product. We hired sales talent. And the results speak for themselves: $1.2M new enterprise ARR in Q2 alone."

**Lesson** (1 sentence, forward):
"This quarter, we're doubling down on enterprise, and we expect to cross $3M ARR by year-end."

### Metrics Storytelling
Don't present metrics in isolation. Connect them to narratives:

**Bad**: "We hit 78% gross margin this quarter."
**Good**: "By moving from on-prem to SaaS delivery, we've improved gross margin from 65% to 78% — that's $300K in additional profit per $1M of revenue."

**Bad**: "CAC increased from $8K to $9.5K."
**Good**: "We've intentionally shifted spend toward enterprise. Enterprise CAC is $18K, but LTV is $180K (10:1 ratio), versus SMB's 3:1. The higher CAC is a strategic choice."

## Handling Tough Questions (Prep 1 week before)

### Common Board Objections & Responses

**"Your churn is 4.2%. That's above industry benchmark."**
- Acknowledge: "You're right, industry for our segment is 3%. Here's why ours is higher."
- Context: "Our product is self-serve; we attract price-sensitive customers who often grow into or out of our pricing tier."
- Plan: "We've identified the churn drivers (see slide 10), and we're piloting a mid-market tier that should drop churn to 3% by Q3."
- Request: "We'd like board support on introducing this tier — it requires pricing change signoff from you."

**"You missed your growth target by 15%."**
- Ownership: "We did. We set aggressive growth targets, and we fell short on enterprise sales conversion (65% vs. 80% plan)."
- Context: "The market for [product category] slowed in April/May due to budget freezes."
- Specificity: "3 of our 4 large deals pushed to Q3; we have high conviction on closing them."
- Plan: "Here's what we changed: [new sales process, new hire, new messaging]. We're tracking early indicators weekly."
- Confidence: "For Q3, we're targeting 110% to catch up. I'm confident in this because [specific data point]."

**"Your burn rate is high. What's your path to profitability?"**
- Acknowledge: "Fair point. At $320K/month, we need to either cut costs or grow revenue faster."
- Data: "Our magic number is 0.92 — for every dollar we burn, we generate $0.92 in new ARR. We need 1.0+."
- Plan: "Here are our levers: (1) Reduce CAC by 15% through product-led growth, (2) Improve NRR from 115% to 125%, (3) Right-size ops overhead."
- Timeline: "We expect to hit 1.0 magic number by Q4."
- Realistic: "Profitability is likely 18-24 months away if we scale. That's why we're raising Series A."

### The "Socratic Method" Reframe
When asked a hard question, turn it back:

**"How are you going to catch up on your growth?"**
Response: "Great question. Let me ask you first: What are the leading indicators you'd want to see in the next 4 weeks that would tell you we're on track?"

This does three things:
1. Buys you time to think
2. Signals confidence (you're not defensive)
3. Aligns board on what success looks like

## Pre-Meeting Checklist (1 day before)

- [ ] Deck finalized, spell-checked, no typos
- [ ] All data validated (Q-o-Q, Y-o-Y, vs. plan)
- [ ] Printouts prepared (2 copies per board member, plus 5 extra)
- [ ] Backup deck on USB drive and cloud
- [ ] Metrics dashboard printed (for reference during Q&A)
- [ ] War room for "Board Q&A" prep session with executive team (2 hours)
  - [ ] Role-play tough questions
  - [ ] Practice 60-second responses
  - [ ] Identify decision points that need alignment before meeting
- [ ] Logistics confirmed: Attendee list, AV tested, room temperature, catering
- [ ] Post-meeting plan: Action items documented, timeline assigned, owner accountable

## Post-Meeting (24 hours after)

1. **Decisions log**: Document all board feedback, decisions made, approvals granted
2. **Action items**: Owner, due date, follow-up accountability
3. **Board memo**: 1-page summary to board + CFO + key executives
4. **Follow-ups**: Personal thank-you emails to each board member (1-2 personalized sentences)
5. **Execution**: Cascade decisions to team via all-hands

---

**Golden Rule**: Board meetings aren't about impressing with data. They're about transparency, accountability, and alignment. The best meetings leave board members clear on where you're headed and confident you'll get there.
